package com.examplepack.tridipbhowmik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ghost extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,bt1,bt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ghost);
        b1=findViewById(R.id.btn1);
        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);
        b4=findViewById(R.id.btn4);
        b5=findViewById(R.id.btn5);
        b6=findViewById(R.id.btn6);
        b7=findViewById(R.id.btn7);
        b8=findViewById(R.id.btn8);
        b9=findViewById(R.id.btn9);
        b10=findViewById(R.id.btn10);
        b11=findViewById(R.id.btn11);
        b12=findViewById(R.id.btn12);
        b13=findViewById(R.id.btn13);
        b14=findViewById(R.id.btn14);
        b15=findViewById(R.id.btn15);

        bt1=findViewById(R.id.backgo);
        bt2=findViewById(R.id.nextfini);

    }

    public void imam(View view) {
        Intent im=new Intent(Ghost.this,ImamerCele.class);
        startActivity(im);
    }

    public void vpisac(View view) {
        Intent vpisac=new Intent(Ghost.this,VoyonkorPisac.class);
        startActivity(vpisac);
    }

    public void aamgachervhut(View view) {
        Intent aamvhut=new Intent(Ghost.this,AamGacherVhut.class);
        startActivity(aamvhut);
    }

    public void jadurputul(View view) {
        Intent jadu=new Intent(Ghost.this,JadurPutul.class);
        startActivity(jadu);
    }

    public void npremik(View view) {
        Intent npre=new Intent(Ghost.this,NorokhadokPremik.class);
        startActivity(npre);
    }

    public void dark1(View view) {
        Intent d1=new Intent(Ghost.this,DarkCity1.class);
        startActivity(d1);
    }

    public void dark2(View view) {
        Intent d2=new Intent(Ghost.this,DarkCity2.class);
        startActivity(d2);
    }

    public void dark3(View view) {
        Intent d3=new Intent(Ghost.this,DarkCity3.class);
        startActivity(d3);
    }

    public void dark4(View view) {
        Intent d4=new Intent(Ghost.this,DarkCity4.class);
        startActivity(d4);
    }

    public void dark5(View view) {
        Intent d5=new Intent(Ghost.this,DarkCity5.class);
        startActivity(d5);
    }

    public void hospitalmorh(View view) {
        Intent hosmorgh=new Intent(Ghost.this,HospitalerMorgh.class);
        startActivity(hosmorgh);
    }

    public void vrat(View view) {
        Intent voyonkorrat=new Intent(Ghost.this,VoyonkarRat.class);
        startActivity(voyonkorrat);
    }

    public void vhutbagan(View view) {
        Intent vbagan=new Intent(Ghost.this,VoutikBagan.class);
        startActivity(vbagan);
    }

    public void vhutbelgach(View view) {
        Intent belgach=new Intent(Ghost.this,VoutikBelGach.class);
        startActivity(belgach);
    }

    public void railstation(View view) {
        Intent rail=new Intent(Ghost.this,Railstation.class);
        startActivity(rail);
    }

    public void back(View view) {
        Intent ba=new Intent(Ghost.this,FirstPage.class);
        startActivity(ba);
    }

    public void finis(View view) {
        Intent ne=new Intent(Ghost.this,FirstPage.class);
        startActivity(ne);
    }
}