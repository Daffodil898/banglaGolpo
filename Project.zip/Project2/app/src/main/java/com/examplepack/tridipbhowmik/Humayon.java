package com.examplepack.tridipbhowmik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Humayon extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,bt1,bt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_humayon);
        b1=findViewById(R.id.btn1);
        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);
        b4=findViewById(R.id.btn4);
        b5=findViewById(R.id.btn5);
        b6=findViewById(R.id.btn6);
        b7=findViewById(R.id.btn7);
        b8=findViewById(R.id.btn8);
        b10=findViewById(R.id.btn10);
        b11=findViewById(R.id.btn11);
        b12=findViewById(R.id.btn12);
        b13=findViewById(R.id.btn13);
        b14=findViewById(R.id.btn14);
        b15=findViewById(R.id.btn15);
        b16=findViewById(R.id.btn16);
        b17=findViewById(R.id.btn17);
        b18=findViewById(R.id.btn18);
        b19=findViewById(R.id.btn19);
        b20=findViewById(R.id.btn20);

        bt1=findViewById(R.id.backhu);
        bt2=findViewById(R.id.nexthu);

    }

    public void aaj(View view) {
        Intent aj=new Intent(Humayon.this,AajDupure.class);
        startActivity(aj);

    }

    public void ala(View view) {
        Intent ala=new Intent(Humayon.this,AlauddinerFasi.class);
        startActivity(ala);
    }

    public void valovasa(View view) {
        Intent lv=new Intent(Humayon.this,Valobasa.class);
        startActivity(lv);
    }


    public void sahi(View view) {
        Intent sah=new Intent(Humayon.this,SahittoBasor.class);
        startActivity(sah);
    }

    public void parul(View view) {
        Intent paru=new Intent(Humayon.this,Parulapa.class);
        startActivity(paru);
    }

    public void rupa(View view) {
        Intent ru=new Intent(Humayon.this,Rupa.class);
        startActivity(ru);
    }

    public void nondini(View view) {
        Intent non=new Intent(Humayon.this,Nondini.class);
        startActivity(non);
    }

    public void nilhati(View view) {
        Intent nil=new Intent(Humayon.this,Nilhati.class);
        startActivity(nil);
    }

    public void akjonsokhindar(View view) {
        Intent ak=new Intent(Humayon.this,AkjonSokhindarManush.class);
        startActivity(ak);
    }

    public void chor(View view) {
        Intent ch=new Intent(Humayon.this,Chor.class);
        startActivity(ch);
    }

    public void jolkonna(View view) {
        Intent j=new Intent(Humayon.this,Jolkonna.class);
        startActivity(j);
    }

    public void sadagari(View view) {
        Intent sada=new Intent(Humayon.this,SadaGari.class);
        startActivity(sada);
    }

    public void pathor(View view) {
        Intent path=new Intent(Humayon.this,Pathor.class);
        startActivity(path);
    }

    public void golon(View view) {
        Intent gol=new Intent(Humayon.this,GolonKotha.class);
        startActivity(gol);
    }

    public void ayna(View view) {
        Intent ayna=new Intent(Humayon.this,Ayna.class);
        startActivity(ayna);
    }

    public void nilbotam(View view) {
        Intent nilb=new Intent(Humayon.this,AktiNilBottam.class);
        startActivity(nilb);
    }

    public void kukur(View view) {
        Intent ku=new Intent(Humayon.this,Kukur.class);
        startActivity(ku);
    }

    public void chayasongi(View view) {
        Intent chaya=new Intent(Humayon.this,Chayasongi.class);
        startActivity(chaya);
    }

    public void mojid(View view) {
        Intent moj=new Intent(Humayon.this,MojidSaheb.class);
        startActivity(moj);
    }

    public void bcman(View view) {
        Intent ba=new Intent(Humayon.this,FirstPage.class);
        startActivity(ba);
    }

    public void ncman(View view) {
        Intent ca=new Intent(Humayon.this,Ghost.class);
        startActivity(ca);
    }
}