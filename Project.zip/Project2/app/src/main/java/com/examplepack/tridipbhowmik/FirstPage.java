package com.examplepack.tridipbhowmik;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class FirstPage extends AppCompatActivity {
    TextView t1,t3,t4,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);
        t1=findViewById(R.id.rabitxt);
        t2=findViewById(R.id.satyatxt);
        t3=findViewById(R.id.humatxt);
        t4=findViewById(R.id.ghostxt);
    }

    public void rabi(View view) {
        Intent rabindra=new Intent(FirstPage.this,Rabindranath.class);
        startActivity(rabindra);
    }

    public void humayon(View view) {
        Intent hum=new Intent(FirstPage.this,Humayon.class);
        startActivity(hum);
    }

    public void ghost(View view) {
        Intent ghost=new Intent(FirstPage.this,Ghost.class);
        startActivity(ghost);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            Intent intent=new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT,"check out this application");
            intent.putExtra(Intent.EXTRA_TEXT,"Your application link here");
            startActivity(Intent.createChooser(intent,"shareVia"));
            return true;
    }

    public void sarat(View view) {
        Intent sat=new Intent(FirstPage.this,SatyayjitRay.class);
        startActivity(sat);
    }
}