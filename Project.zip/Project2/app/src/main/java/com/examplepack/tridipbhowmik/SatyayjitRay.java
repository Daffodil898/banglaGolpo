package com.examplepack.tridipbhowmik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SatyayjitRay extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,bt1,bt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_satyayjit_ray);
        bt1=findViewById(R.id.backsat);
        bt2=findViewById(R.id.nextsat);

        b1=findViewById(R.id.btn1);
        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);
        b4=findViewById(R.id.btn4);
        b5=findViewById(R.id.btn5);
        b6=findViewById(R.id.btn6);
        b7=findViewById(R.id.btn7);
        b8=findViewById(R.id.btn8);
        b9=findViewById(R.id.btn9);
        b10=findViewById(R.id.btn10);
        b11=findViewById(R.id.btn11);
        b12=findViewById(R.id.btn12);
        b13=findViewById(R.id.btn13);
        b14=findViewById(R.id.btn14);
        b15=findViewById(R.id.btn15);
        b16=findViewById(R.id.btn16);
        b17=findViewById(R.id.btn17);
        b18=findViewById(R.id.btn18);
        b19=findViewById(R.id.btn19);
        b20=findViewById(R.id.btn20);
    }

    public void duibondu(View view) {
        Intent dui=new Intent(SatyayjitRay.this,DiuBondhu.class);
        startActivity(dui);
    }

    public void apodartho(View view) {
        Intent apo=new Intent(SatyayjitRay.this,Apodartha.class);
        startActivity(apo);
    }

    public void classfrnd(View view) {
        Intent cls=new Intent(SatyayjitRay.this,ClassFriend.class);
        startActivity(cls);
    }

    public void notunbndu(View view) {
        Intent not=new Intent(SatyayjitRay.this,NotunBondhu.class);
        startActivity(not);
    }

    public void vokto(View view) {
        Intent vok=new Intent(SatyayjitRay.this,Vokto.class);
        startActivity(vok);
    }

    public void juti(View view) {
        Intent juti=new Intent(SatyayjitRay.this,Juti.class);
        startActivity(juti);
    }

    public void load(View view) {
        Intent lo=new Intent(SatyayjitRay.this,LoadSheding.class);
        startActivity(lo);
    }

    public void nitaibabu(View view) {
        Intent nitai=new Intent(SatyayjitRay.this,NitayBaburMoyna.class);
        startActivity(nitai);
    }

    public void bohuripi(View view) {
        Intent bohu=new Intent(SatyayjitRay.this,Bohurupi.class);
        startActivity(bohu);
    }

    public void sadhon(View view) {
        Intent sad=new Intent(SatyayjitRay.this,ShadonBabu.class);
        startActivity(sad);
    }

    public void nilatonko(View view) {
        Intent nil=new Intent(SatyayjitRay.this,NilAtonko.class);
        startActivity(nil);
    }

    public void oviram(View view) {
        Intent ovi=new Intent(SatyayjitRay.this,Oviram.class);
        startActivity(ovi);
    }

    public void khogom(View view) {
        Intent kho=new Intent(SatyayjitRay.this,khogom.class);
        startActivity(kho);
    }

    public void dhappa(View view) {
        Intent dha=new Intent(SatyayjitRay.this,Dhappa.class);
        startActivity(dha);
    }

    public void batik(View view) {
        Intent batik=new Intent(SatyayjitRay.this,Batikbabu.class);
        startActivity(batik);
    }

    public void bish(View view) {
        Intent bis=new Intent(SatyayjitRay.this,Bishful.class);
        startActivity(bis);
    }

    public void piku(View view) {
        Intent piku=new Intent(SatyayjitRay.this,PikurDiary.class);
        startActivity(piku);
    }

    public void aamivhut(View view) {
        Intent ami=new Intent(SatyayjitRay.this,AmiVhut.class);
        startActivity(ami);
    }

    public void manprotro(View view) {
        Intent man=new Intent(SatyayjitRay.this,Manprotro.class);
        startActivity(man);
    }

    public void professor(View view) {
        Intent pro=new Intent(SatyayjitRay.this,ProfessorHijibiji.class);
        startActivity(pro);
    }

    public void bcman(View view) {
        Intent po=new Intent(SatyayjitRay.this,FirstPage.class);
        startActivity(po);
    }

    public void ncman(View view) {
        Intent pr=new Intent(SatyayjitRay.this,Humayon.class);
        startActivity(pr);
    }
}