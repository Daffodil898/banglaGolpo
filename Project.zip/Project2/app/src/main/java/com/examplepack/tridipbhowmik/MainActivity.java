package com.examplepack.tridipbhowmik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button gl,rt,at;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gl=findViewById(R.id.btn1);
        rt=findViewById(R.id.strbtn);
        at=findViewById(R.id.extra);
    }

    public void golpo(View view) {
        Intent gol=new Intent(MainActivity.this,FirstPage.class);
        startActivity(gol);
    }

    public void rate(View view) {
        Intent r=new Intent(MainActivity.this,Rating.class);
        startActivity(r);
    }

    public void apps(View view) {
        Intent intent= new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.android.app"));
        startActivity(intent);
    }
}