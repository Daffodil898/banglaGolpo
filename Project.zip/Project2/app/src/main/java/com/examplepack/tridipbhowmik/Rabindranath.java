package com.examplepack.tridipbhowmik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Rabindranath extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,bt1,bt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rabindranath);
        b1=findViewById(R.id.btn1);
        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);
        b4=findViewById(R.id.btn4);
        b5=findViewById(R.id.btn5);
        b6=findViewById(R.id.btn6);
        b7=findViewById(R.id.btn7);
        b8=findViewById(R.id.btn8);
        b9=findViewById(R.id.btn9);
        b10=findViewById(R.id.btn10);
        b11=findViewById(R.id.btn11);
        b12=findViewById(R.id.btn12);
        b13=findViewById(R.id.btndete);
        b14=findViewById(R.id.btn15);

        bt1=findViewById(R.id.backrab);
        bt2=findViewById(R.id.nextrab);



    }

    public void op(View view) {
        Intent opo=new Intent(Rabindranath.this,Opricita.class);
        startActivity(opo);
    }

    public void otithi(View view) {
        Intent othi=new Intent(Rabindranath.this,Otithi.class);
        startActivity(othi);
    }

    public void raj(View view) {
        Intent rajtika=new Intent(Rabindranath.this,Rajtika.class);
        startActivity(rajtika);
    }

    public void sompothi(View view) {
        Intent som=new Intent(Rabindranath.this,Sampothi.class);
        startActivity(som);
    }

    public void dena(View view) {
        Intent dena=new Intent(Rabindranath.this,Denapawna.class);
        startActivity(dena);
    }

    public void cuti(View view) {
        Intent chuti=new Intent(Rabindranath.this,Chuti.class);
        startActivity(chuti);
    }

    public void danpro(View view) {
        Intent dan=new Intent(Rabindranath.this,Danprotidan.class);
        startActivity(dan);
    }

    public void kabliwala(View view) {
        Intent kab=new Intent(Rabindranath.this,Kabliwala.class);
        startActivity(kab);
    }

    public void post(View view) {
        Intent pos=new Intent(Rabindranath.this,PostMaster.class);
        startActivity(pos);
    }

    public void moha(View view) {
        Intent moha=new Intent(Rabindranath.this,Mohamaya.class);
        startActivity(moha);
    }

    public void thakur(View view) {
        Intent th=new Intent(Rabindranath.this,Thakurdha.class);
        startActivity(th);
    }

    public void jibito(View view) {
        Intent jib=new Intent(Rabindranath.this,JibitoOmrito.class);
        startActivity(jib);
    }

    public void dete(View view) {
        Intent de=new Intent(Rabindranath.this,Dete.class);
        startActivity(de);
    }

    public void babo(View view) {
        Intent ba=new Intent(Rabindranath.this,Babodhan.class);
        startActivity(ba);
    }

    public void bcman(View view) {
        Intent ca=new Intent(Rabindranath.this,FirstPage.class);
        startActivity(ca);
    }

    public void ncman(View view) {
        Intent na=new Intent(Rabindranath.this,SatyayjitRay.class);
        startActivity(na);
    }
}